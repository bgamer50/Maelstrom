.. cmake-module:: ../../rapids-cmake/cuda/set_architectures.cmake
