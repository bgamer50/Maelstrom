.. cmake-module:: ../../rapids-cmake/cpm/gbench.cmake
