.. cmake-module:: ../../rapids-cmake/cpm/spdlog.cmake
